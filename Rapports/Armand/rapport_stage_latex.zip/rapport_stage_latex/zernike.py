# 
#Simple simulation of an optics setup: A spatially controllable phase is imprinted on a coherent gaussian beam. The resulting amplitude distribution is fourier-transformed (simulating a focalising lens). The resulting intensity distribution corresponds to the intensity distribution one would measure in the focal plane of the lens.
#
import matplotlib
import numpy as np
import matplotlib.pylab as plt
from scipy.optimize import curve_fit
import random

# create the gaussian amplitude distribution:
deplacement=40
boolLaguerre=1
mirrsize=7.6
wavelength=0.78
kvector = 2*3.14159/wavelength
fLens=20*10**3
nx=900 # number of pixels in x and y direction
ny=900
L=nx*mirrsize
l=ny*mirrsize
x=(np.linspace(-L/2,L/2,nx))
y=(np.linspace(-l/2,l/2,ny))
xv,yv=np.meshgrid(x,y,sparse=True) # meshgrid matrices with values ranging from -1 to 1

#Zernike coefficients
Z0=0*wavelength
Z1=deplacement*yv.max()/(wavelength*fLens)*wavelength*np.sqrt(2)
Z3=0#0.203135*wavelength
Z4=0#0.022448*wavelength
Z6=0#-0.517865*wavelength
Z8=0#-2.119337*wavelength

# size of the gaussian in x and y direction
sigmax=L/20
sigmay=l/20

# make the gaussian amplitude distribution:
GaussMat=np.exp(-xv**2/(2*sigmax**2)-yv**2/(2*sigmay**2))

#Add of the tilt and other aberrations
tilt = [[0 for x in range(nx)] for y in range(ny)]
abb = [[0 for x in range(nx)] for y in range(ny)]
phi = [[0 for x in range(nx)] for y in range(ny)]
rpol = [[0 for x in range(nx)] for y in range(ny)]

for k in range (ny):
        for i in range(nx):
                if xv[0][i]<0:
                        phi[k][i]=3.14159/2-np.arctan(yv[k][0]/xv[0][i])
                        rpol[k][i]=np.sqrt(((yv[k][0])**2+(xv[0][i])**2)/((yv.max())**2+(xv.max())**2))
                        tilt[k][i] = Z0 + Z1*(rpol[k][i])*np.sin(phi[k][i])
                        abb[k][i] =Z3*(2*(rpol[k][i])**2-1) + Z4*(rpol[k][i])**2*np.cos(2*phi[k][i]) + Z6*(3*(rpol[k][i])**2-2)*(rpol[k][i])*np.cos(phi[k][i]) +Z8*(6*(rpol[k][i])**4-6*(rpol[k][i])**2+1)
                if xv[0][i]>0:
                        phi[k][i]=3*3.14159/2-np.arctan(yv[k][0]/xv[0][i])
                        rpol[k][i]=np.sqrt(((yv[k][0])**2+(xv[0][i])**2)/((yv.max())**2+(xv.max())**2))
                        tilt[k][i] = Z0 + Z1*(rpol[k][i])*np.sin(phi[k][i])
                        abb[k][i] =Z3*(2*(rpol[k][i])**2-1) + Z4*(rpol[k][i])**2*np.cos(2*phi[k][i]) + Z6*(3*(rpol[k][i])**2-2)*(rpol[k][i])*np.cos(phi[k][i]) +Z8*(6*(rpol[k][i])**4-6*(rpol[k][i])**2+1)

#Creation of a gaussian beam with aberrations
abb=np.array(abb)
GaussMatAberr=GaussMat*np.exp(1j*abb*kvector)

#MasqueDMD
MasqueDMD = [[0 for x in range(nx)] for y in range(ny)]
for k in range (ny):
        for i in range(nx):
                if boolLaguerre==1:
                        MasqueDMD[k][i]=(np.cos(phi[k][i]+kvector*(tilt[k][i]-abb[k][i]))+1)/2
                if boolLaguerre==0:
                        MasqueDMD[k][i]=(np.cos(kvector*(tilt[k][i]-abb[k][i]))+1)/2
#Decomposition of the masque in a binary one like DMD has to be
for k in range (ny):
        for i in range(nx):     
                prob=MasqueDMD[k][i]
                alea=random.uniform(0.0, 1.0)
                if prob<alea:
                        MasqueDMD[k][i]=0.5
                if prob>=alea:
                        MasqueDMD[k][i]=-0.5

#Correction and tilting of the beam thanks to the DMD                   
GaussMatAberrCorr=GaussMatAberr*MasqueDMD

# plot the DMD 
fig1=plt.figure()
plt.imshow(tilt, interpolation='nearest',cmap=plt.cm.gist_gray, origin='lower',extent=(xv.min(),xv.max(),yv.min(),yv.max()))
plt.colorbar()

# calculate the fourier transform of gaussian beam
TFGaussMat=np.fft.fft2(GaussMat)
TFGaussMat=np.fft.fftshift(TFGaussMat)

# calculate the fourier transform of gaussian beam with aberration
TFGaussMatAberr=np.fft.fft2(GaussMatAberr)
TFGaussMatAberr=np.fft.fftshift(TFGaussMatAberr)

# calculate the fourier transform of gaussian beam with aberration corrected by DMD
TFGaussMatAberrCorr=np.fft.fft2(GaussMatAberrCorr)
TFGaussMatAberrCorr=np.fft.fftshift(TFGaussMatAberrCorr)

# plot the final intensity distribution in the focal plane of the lens:
fig2=plt.figure()
plt.imshow(np.abs(TFGaussMatAberrCorr)**2, interpolation='nearest',cmap=plt.cm.gist_gray, origin='lower',extent=(wavelength*fLens/(nx*mirrsize**2)*xv.min(),wavelength*fLens/(nx*mirrsize**2)*xv.max(),wavelength*fLens/(ny*mirrsize**2)*yv.min(),wavelength*fLens/(ny*mirrsize**2)*yv.max()))
plt.colorbar()

fig3=plt.figure()
plt.imshow(np.abs(TFGaussMatAberr)**2, interpolation='nearest',cmap=plt.cm.gist_gray, origin='lower',extent=(wavelength*fLens/(nx*mirrsize**2)*xv.min(),wavelength*fLens/(nx*mirrsize**2)*xv.max(),wavelength*fLens/(ny*mirrsize**2)*yv.min(),wavelength*fLens/(ny*mirrsize**2)*yv.max()))
plt.colorbar()

#Gaussian fit for maximum calculation (determination of the focal point emplacement)

if boolLaguerre==0:
        def gaus(fxplot,a,xmax,sigma):
            return a*np.exp(-2*(3.14159**2)*(fxplot-xmax)**2*sigma**2/((wavelength*fLens)**2))
        yplot = np.zeros(nx)
        for i in range(nx):
                yplot[i] = np.abs(TFGaussMatAberrCorr[round((ny-1)/2,0)][i])
        fxplot = wavelength*fLens/(nx*mirrsize**2)*x
        a_init = max(yplot)#in order to help the fit for converging
        xmax_init = wavelength*fLens/(nx*mirrsize**2)*x[np.where(yplot==max(yplot))[0][0]]#idem
        popt,pcov = curve_fit(gaus,fxplot,yplot,p0 = [a_init, xmax_init, sigmax])

#plot gaussian fit
        fig4=plt.figure()
        plt.plot(fxplot,gaus(fxplot,*popt))
        plt.plot(fxplot,yplot,'g+:')
        print(popt)

plt.show()


